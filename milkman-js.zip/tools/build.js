{
    "baseUrl": "../lib",
    "paths": {
        "milkman": "../milkman"
    },
    "include": ["../tools/almond", "milkman"],
    "exclude": ["jquery"],
    "out": "../dist/milkman.js",
    "wrap": {
        "startFile": "wrap.start",
        "endFile": "wrap.end"
    }
}
