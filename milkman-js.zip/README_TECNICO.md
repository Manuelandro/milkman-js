



## How to build the library

    node tools/r.js -o tools/build.js

## Running

You must install all dependencies.

First include in your project:

    directory dist/milkman.js
    
Simply call milkman. with one of the supported input types.

    ex: milkman.createRecord('entity', 'details');

## Credit

This library was created by [Francesca Barbazeni].  This README document was written by Francesca Barbazeni.

## HOW TO EXPORT

dist/*
lib/jquery
tests/*
